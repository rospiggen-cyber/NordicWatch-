
const CACHE = 'nordicwatch-v01';
const APP = ['./','index.html','styles.css','app.js','manifest.webmanifest','icon.svg'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(APP)));
});
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(cached => cached || fetch(event.request))
  );
});
