# NordicWatch v0.1

Mobile-first Nordic situational-awareness PWA prototype.

## Included
- Nordic/Baltic map
- Hotspot layer
- Military activity layer
- Critical infrastructure layer
- GPS interference layer
- Activity Index
- 6h / 24h / 3d / 7d / 30d controls
- "What changed?" delta drawer
- Responsive mobile UI
- PWA manifest + service worker
- Demo/mock data only

## Run locally
Because the app uses a service worker, serve it over HTTP rather than opening index.html directly.

Python:
    python -m http.server 8080

Then open:
    http://localhost:8080

## Deployment
This folder can be deployed as-is to GitHub Pages, Netlify, Cloudflare Pages or any static web host.

## Next integrations
Suggested order:
1. News/OSINT event feed
2. ADS-B / military aviation feed where legally/technically available
3. AIS maritime feed
4. GNSS interference data
5. NOTAM / airspace notices
6. infrastructure/outage feeds
7. baseline/anomaly engine
8. source confidence + provenance
